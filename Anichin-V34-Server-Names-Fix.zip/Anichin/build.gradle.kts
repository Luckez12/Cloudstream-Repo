version = 34
cloudstream {
    description = "Anichin — Streaming Donghua Subtitle Indonesia"
    language = "id"
    authors = listOf("Luckez")
    status = 1

    tvTypes = listOf(
        "Anime",
        "Movie",
    )

    iconUrl = "https://t2.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=https://anichin.moe&size=%size%"
}
