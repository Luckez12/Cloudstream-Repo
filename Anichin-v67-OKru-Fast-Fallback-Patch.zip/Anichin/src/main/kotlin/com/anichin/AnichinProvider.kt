package com.anichin

import android.util.Base64
import android.util.Log
import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.selects.select
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withTimeoutOrNull
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URI
import java.net.URLEncoder
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

class AnichinProvider : MainAPI() {

    override var mainUrl = "https://anichin.moe"
    override var name = "Anichin"
    override val hasMainPage = true
    override var lang = "id"
    override val hasDownloadSupport = true

    override val supportedTypes = setOf(
        TvType.Movie,
        TvType.Anime
    )

    override val mainPage = mainPageOf(
        HOMEPAGE_LATEST_ROUTE to "Latest Release",
        "anime/?type=movie&order=update" to "Movie",
        "anime/?order=popular" to "Popular",
        "anime/?status=completed&order=update" to "Completed"
    )

    private val siteHeaders = mapOf(
        "User-Agent" to USER_AGENT,
        "Accept" to "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language" to "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"
    )

    private fun imageHeadersFor(imageUrl: String?): Map<String, String> {
        val headers = mutableMapOf(
            "User-Agent" to USER_AGENT,
            "Accept" to "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
            "Accept-Language" to "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
            "Referer" to "$mainUrl/"
        )

        val imageHost = imageUrl
            ?.takeUnless { it.startsWith("data:", true) }
            ?.let(::hostOf)
            .orEmpty()

        val siteHost = hostOf(mainUrl)
        val cookies = when {
            imageHost.isBlank() -> sharedCloudflareKiller.savedCookies[siteHost]
            imageHost == siteHost || imageHost.endsWith(".$siteHost") ->
                sharedCloudflareKiller.savedCookies[imageHost]
                    ?: sharedCloudflareKiller.savedCookies[siteHost]
            else -> sharedCloudflareKiller.savedCookies[imageHost]
        }

        if (!cookies.isNullOrEmpty()) {
            headers["Cookie"] = cookies.entries.joinToString("; ") {
                "${it.key}=${it.value}"
            }
        }

        return headers
    }

    private fun hostOf(url: String): String = runCatching {
        URI(url).host.orEmpty()
    }.getOrDefault("")

    // Challenge recovery is coordinated inside the interceptor. Ordinary HTTP
    // failures must not erase a valid clearance or start a second page request.
    private suspend fun fetchSiteDocument(
        url: String,
        referer: String = "$mainUrl/"
    ): Document {
        val response = app.get(
            url,
            headers = siteHeaders,
            referer = referer,
            timeout = SITE_REQUEST_TIMEOUT_SECONDS,
            interceptor = sharedCloudflareKiller
        )
        if (!response.isSuccessful) {
            val status = response.code
            response.okhttpResponse.close()
            throw IllegalStateException("HTTP $status from ${hostOf(url)}")
        }
        val document = response.document
        if (document.isCloudflareChallenge()) {
            response.okhttpResponse.close()
            throw IllegalStateException("Cloudflare challenge from ${hostOf(url)}")
        }
        return document
    }

    private fun Document.isCloudflareChallenge(): Boolean {
        val pageTitle = title().trim()
        if (
            pageTitle.equals("Just a moment...", ignoreCase = true) ||
            pageTitle.contains("Attention Required", ignoreCase = true)
        ) {
            return true
        }

        if (
            selectFirst(
                "#challenge-platform, #challenge-form, " +
                    "form[action*=\"/cdn-cgi/challenge-platform\"], " +
                    "script[src*=\"challenges.cloudflare.com\"]"
            ) != null
        ) {
            return true
        }

        val pageText = text()
        return pageText.contains("Performing security verification", ignoreCase = true) ||
            pageText.contains("Checking your browser before accessing", ignoreCase = true)
    }

    private data class PlayerOption(
        val label: String,
        val url: String,
        val selectionRank: Int
    )

    private data class ImageSelection(
        val url: String?,
        val source: String
    )

    private fun Element.selectImage(): ImageSelection {
        fun srcset(value: String): String? {
            val candidates = value
                .split(',')
                .mapNotNull { entry ->
                    val parts = entry.trim().split(Regex("""\s+"""))
                    val url = parts.firstOrNull()
                        ?.takeIf {
                            it.isNotBlank() && !it.startsWith("data:", true)
                        }
                        ?: return@mapNotNull null
                    val width = parts.getOrNull(1)
                        ?.removeSuffix("w")
                        ?.toIntOrNull()
                    url to width
                }

            return candidates
                .filter { (_, width) -> width != null && width >= MIN_POSTER_WIDTH }
                .minByOrNull { (_, width) -> width ?: Int.MAX_VALUE }
                ?.first
                ?: candidates.lastOrNull()?.first
        }

        // Lazy-load plugins put the canonical image in data-src/data-lazy-src.
        // Prefer that exact URL before choosing one responsive srcset variant.
        val candidates = listOf(
            "data-src" to attr("data-src"),
            "data-lazy-src" to attr("data-lazy-src"),
            "data-original" to attr("data-original"),
            "data-cfsrc" to attr("data-cfsrc"),
            "data-lazy-srcset" to srcset(attr("data-lazy-srcset")),
            "data-srcset" to srcset(attr("data-srcset")),
            "srcset" to srcset(attr("srcset")),
            "src" to attr("src")
        )

        val selected = candidates.firstOrNull { (_, imageUrl) ->
            !imageUrl.isNullOrBlank() &&
                !imageUrl.startsWith("data:", ignoreCase = true)
        }
        return ImageSelection(selected?.second, selected?.first ?: "none")
    }

    private data class CardData(
        val title: String,
        val href: String,
        val poster: String?,
        val posterSource: String,
        val type: TvType
    )

    private data class HomeCacheEntry(val createdAt: Long, val response: HomePageResponse)
    private val homeCache = ConcurrentHashMap<String, HomeCacheEntry>()
    private val homeLocks = ConcurrentHashMap<String, Mutex>()

    override suspend fun getMainPage(page: Int, request: MainPageRequest): HomePageResponse {
        // Cache only the four first-page sections, never episode/player data.
        if (page != 1 || mainPage.none { it.data == request.data }) {
            return fetchMainPage(page, request)
        }
        val key = "$mainUrl|${request.data}"
        return homeLocks.getOrPut(key) { Mutex() }.withLock {
            val cached = homeCache[key]
            if (cached != null && System.nanoTime() - cached.createdAt < HOME_CACHE_TTL_NS) {
                return@withLock cached.response
            }
            val response = fetchMainPage(page, request)
            if (response.items.any { it.list.isNotEmpty() }) {
                homeCache[key] = HomeCacheEntry(System.nanoTime(), response)
            }
            response
        }
    }

    private suspend fun fetchMainPage(
        page: Int,
        request: MainPageRequest
    ): HomePageResponse {

        val isLatestRelease = request.data == HOMEPAGE_LATEST_ROUTE
        val archiveRoute = if (isLatestRelease) LATEST_ARCHIVE_ROUTE else request.data
        val archiveUrl = buildArchivePageUrl(archiveRoute, page)

        val document: Document
        val cards: List<CardData>
        var source = "archive"

        val typeHint = if (
            archiveRoute.contains("type=movie", ignoreCase = true)
        ) {
            TvType.Movie
        } else {
            null
        }

        if (isLatestRelease) {
            val homepageUrl = latestHomepageUrl(page)
            val homepageDocument = try {
                fetchSiteDocument(homepageUrl)
            } catch (e: CancellationException) {
                throw e
            } catch (_: Throwable) {
                null
            }

            val homepageCards = homepageDocument
                ?.latestReleaseArticles()
                ?.mapNotNull { it.toCardData() }
                ?.distinctBy { it.href }
                .orEmpty()

            if (homepageDocument != null && homepageCards.isNotEmpty()) {
                document = homepageDocument
                cards = homepageCards
                source = "homepage"
            } else {
                document = fetchSiteDocument(archiveUrl)
                cards = document.archiveArticles(typeHint)
                source = "fallback"
            }
        } else {
            document = fetchSiteDocument(archiveUrl)
            cards = document.archiveArticles(typeHint)
        }

        Log.i(
            "Anichin",
            "ANICHIN_V67_HOME name=${request.name} source=$source page=$page cards=${cards.size}"
        )

        if (isLatestRelease) {
            Log.i(
                "Anichin",
                "ANICHIN_V67_LATEST page=$page source=$source first=" +
                    cards.take(LATEST_DIAGNOSTIC_LIMIT)
                        .joinToString(" | ") { it.title }
            )
        }

        val home = buildSearchResponses(cards)

        val hasNext = document.selectFirst(
            "a.next.page-numbers, .pagination .next a, .hpage a.r, a[rel=next]"
        ) != null

        return newHomePageResponse(
            list = HomePageList(
                name = request.name,
                list = home,
                isHorizontalImages = false
            ),
            hasNext = hasNext
        )
    }

    private fun buildArchivePageUrl(route: String, page: Int): String {
        val separator = if (route.contains('?')) "&" else "?"
        return "$mainUrl/$route${separator}page=$page"
    }

    private fun latestHomepageUrl(page: Int): String {
        return if (page <= 1) "$mainUrl/" else "$mainUrl/page/$page/"
    }

    private fun Document.archiveArticles(typeHint: TvType?): List<CardData> =
        select("div.listupd > article")
            .mapNotNull { it.toCardData(typeHint) }
            .distinctBy { it.href }

    private fun Document.latestReleaseArticles(): List<Element> {
        val latestHeading = select("h1, h2, h3, h4, .releases h1, .releases h2, .releases h3")
            .firstOrNull { heading ->
                val label = heading.text().trim()
                LATEST_HEADING_LABELS.any { expected ->
                    label.contains(expected, ignoreCase = true)
                }
            }

        fun Element.scopedArticles(): List<Element> {
            val direct = children().filter { child ->
                child.tagName().equals("article", ignoreCase = true)
            }
            return direct.takeIf { it.isNotEmpty() }
                ?: select("article").toList()
        }

        var scope = latestHeading?.parent()
        repeat(LATEST_BLOCK_SEARCH_DEPTH) { depth ->
            val directList = scope
                ?.children()
                ?.firstOrNull { child -> child.hasClass("listupd") }

            directList?.scopedArticles()?.takeIf { it.isNotEmpty() }?.let {
                Log.i("Anichin", "ANICHIN_V67_LATEST_BLOCK mode=child depth=$depth")
                return it
            }

            var sibling = scope?.nextElementSibling()
            repeat(LATEST_SIBLING_SEARCH_LIMIT) {
                if (sibling?.hasClass("listupd") == true) {
                    sibling?.scopedArticles()?.takeIf { it.isNotEmpty() }?.let { articles ->
                        Log.i(
                            "Anichin",
                            "ANICHIN_V67_LATEST_BLOCK mode=sibling depth=$depth"
                        )
                        return articles
                    }
                }
                sibling = sibling?.nextElementSibling()
            }

            scope = scope?.parent()
        }

        val fallback = select("div.listupd")
            .map { list ->
                list.scopedArticles()
            }
            .firstOrNull { it.isNotEmpty() }
            .orEmpty()

        Log.w(
            "Anichin",
            "ANICHIN_V67_LATEST_BLOCK mode=fallback cards=${fallback.size}"
        )
        return fallback
    }

    private fun Element.toCardData(
        typeHint: TvType? = null
    ): CardData? {

        val anchor = selectFirst("div.bsx > a[href]")
            ?: selectFirst("a[href]")
            ?: return null

        val title = anchor
            .attr("title")
            .trim()
            .ifBlank {
                selectFirst(".tt, h2, h3")
                    ?.text()
                    ?.trim()
                    .orEmpty()
            }

        if (title.isBlank()) return null

        val href = fixUrl(anchor.attr("href"))

        val posterSelection = selectFirst("div.bsx > a img, img")
            ?.selectImage()
            ?: ImageSelection(null, "missing-img")

        val badge = selectFirst(".typez, .type, .status")
            ?.text()
            .orEmpty()

        val tvType = when {
            typeHint == TvType.Movie -> TvType.Movie
            badge.contains("Movie", ignoreCase = true) -> TvType.Movie
            href.contains("-movie-", ignoreCase = true) -> TvType.Movie
            else -> TvType.Anime
        }

        return CardData(
            title,
            href,
            posterSelection.url,
            posterSelection.source,
            tvType
        )
    }

    private fun buildSearchResponses(
        cards: List<CardData>
    ): List<SearchResponse> {
        cards.take(POSTER_DIAGNOSTIC_LIMIT).forEachIndexed { index, card ->
            val fixed = card.poster?.let { fixUrlNull(it) }
            Log.i(
                "Anichin",
                "ANICHIN_V67_POSTER index=${index + 1} " +
                    "source=${card.posterSource} host=${fixed?.let(::hostOf).orEmpty()} " +
                    "url=${fixed.orEmpty()}"
            )
        }

        return cards.map { card ->
            val fixedPoster = card.poster?.let { fixUrlNull(it) }

            newAnimeSearchResponse(
                card.title,
                card.href,
                card.type
            ) {
                this.posterUrl = fixedPoster
                this.posterHeaders = imageHeadersFor(fixedPoster)
            }
        }
    }

    override suspend fun search(
        query: String
    ): List<SearchResponse> {

        val encodedQuery = URLEncoder.encode(
            query.trim(),
            "UTF-8"
        )

        if (encodedQuery.isBlank()) {
            return emptyList()
        }

        val searchResponse = mutableListOf<SearchResponse>()

        for (page in 1..3) {

            val pageUrl = "${mainUrl}/page/$page/?s=$encodedQuery"
            val document = fetchSiteDocument(pageUrl)

            val cards = document
                .select("div.listupd > article")
                .mapNotNull { it.toCardData() }

            val results = buildSearchResponses(cards)

            if (results.isEmpty()) break

            searchResponse.addAll(results)
        }

        return searchResponse.distinctBy { it.url }
    }

    private fun isSeoSynopsis(
        text: String
    ): Boolean {
        val lower = text.lowercase()

        if (lower.startsWith("tonton streaming")) return true
        if (lower.startsWith("nonton ") && lower.contains("terlengkap")) return true

        val hits = listOf(
            "download gratis",
            "berbagai kualitas",
            "menghemat kuota",
            "mp4 mkv",
            "hardsub softsub",
            "streaming online",
            "di anichin"
        ).count { lower.contains(it) }

        return hits >= 2
    }

    private fun cleanSynopsis(raw: String?): String? {
        val text = raw
            ?.replace('\u00a0', ' ')
            ?.replace(Regex("""\s+"""), " ")
            ?.trim()
            .orEmpty()

        if (text.length < 35) return null
        if (isSeoSynopsis(text)) return null
        return text
    }

    private fun extractSynopsis(document: Document): String? {
        val heading = document.select("h2, h3, h4, h5")
            .firstOrNull {
                it.text().contains("Sinopsis", ignoreCase = true)
            }

        if (heading != null) {
            val paragraphs = mutableListOf<String>()
            var node = heading.nextElementSibling()

            repeat(10) {
                val current = node ?: return@repeat

                if (
                    current.tagName().lowercase() in
                    setOf("h1", "h2", "h3", "h4", "h5")
                ) {
                    node = null
                    return@repeat
                }

                val candidates = if (
                    current.tagName().equals("p", ignoreCase = true)
                ) {
                    listOf(current.text())
                } else {
                    current.select("p").map { it.text() }
                }

                candidates.mapNotNull(::cleanSynopsis)
                    .forEach(paragraphs::add)

                node = current.nextElementSibling()
            }

            if (paragraphs.isNotEmpty()) {
                return paragraphs.distinct().joinToString("\n\n")
            }
        }

        document.select(
            ".synp .entry-content, .synopsis, .sinopsis, .desc"
        ).forEach { container ->
            val paragraphs = container.select("p")
                .mapNotNull { cleanSynopsis(it.text()) }
                .distinct()

            if (paragraphs.isNotEmpty()) {
                return paragraphs.joinToString("\n\n")
            }

            cleanSynopsis(container.text())?.let { return it }
        }

        val contentParagraphs = document
            .select("div.entry-content p")
            .mapNotNull { cleanSynopsis(it.text()) }
            .filterNot {
                it.contains("server streaming", ignoreCase = true) ||
                    it.contains("grup telegram", ignoreCase = true)
            }
            .distinct()

        return contentParagraphs
            .takeIf { it.isNotEmpty() }
            ?.joinToString("\n\n")
    }

    private fun episodeNumberFrom(
        episodeElement: Element,
        link: String,
        title: String
    ): Double? {
        /*
         * V25: trust the episode permalink first.
         *
         * Some Anichin rows expose an internal/global counter in .epl-num.
         * Martial Master is one example: the row can show 7574 while the
         * actual episode permalink is ...-episode-690-....
         *
         * The permalink represents the playable episode, so it is the most
         * reliable source for Cloudstream episode grouping.
         */
        val urlNumber = Regex(
            """-episode-(\d+(?:\.\d+)?)""",
            RegexOption.IGNORE_CASE
        ).find(link)
            ?.groupValues
            ?.getOrNull(1)
            ?.toDoubleOrNull()

        if (urlNumber != null) {
            return urlNumber
        }

        /*
         * Fallback 2: explicit number in the episode title.
         *
         * This must come before .epl-num because Anichin occasionally stores
         * the WordPress/post counter there instead of the actual episode.
         * Example:
         *   .epl-num = 7574
         *   title    = Martial Master Episode 574 Subtitle Indonesia
         */
        val titleNumber = Regex(
            """(?:Episode|Ep|Eps)\s*(\d+(?:\.\d+)?)""",
            RegexOption.IGNORE_CASE
        ).find(title)
            ?.groupValues
            ?.getOrNull(1)
            ?.toDoubleOrNull()

        if (titleNumber != null) {
            return titleNumber
        }

        /*
         * Last fallback only: dedicated number column.
         * Keep it for older pages that have neither a numeric permalink nor
         * an explicit Episode token in the title.
         */
        val globalNumberText = episodeElement
            .selectFirst(".epl-num, .epnum, .episode-number")
            ?.text()
            ?.trim()
            .orEmpty()

        return Regex(
            """\d+(?:\.\d+)?"""
        ).find(globalNumberText)
            ?.value
            ?.toDoubleOrNull()
    }

    private fun cleanEpisodeDisplayTitle(
        rawTitle: String,
        episodeNumber: Double?
    ): String {
        var cleaned = rawTitle
            .replace(
                Regex(
                    """Episode\s*\d+(?:\.\d+)?\s*Subtitle Indonesia""",
                    RegexOption.IGNORE_CASE
                ),
                ""
            )
            .replace(
                "Subtitle Indonesia",
                "",
                ignoreCase = true
            )
            .trim()

        /*
         * Some templates prefix the visible title with the same bad internal
         * counter that appears in .epl-num, e.g. "7574. - Martial Master".
         * Strip that prefix only when it disagrees with the permalink episode.
         */
        val leadingCounter = Regex(
            """^\s*(\d+(?:\.\d+)?)\s*[.\-:]+\s*"""
        ).find(cleaned)

        if (leadingCounter != null && episodeNumber != null) {
            val counter = leadingCounter
                .groupValues
                .getOrNull(1)
                ?.toDoubleOrNull()

            if (counter != null && counter != episodeNumber) {
                cleaned = cleaned
                    .removeRange(leadingCounter.range)
                    .trim()
            }
        }

        return cleaned.ifBlank {
            episodeNumber?.let { number ->
                if (number % 1.0 == 0.0) {
                    "Episode ${number.toInt()}"
                } else {
                    "Episode $number"
                }
            } ?: rawTitle
        }
    }

    override suspend fun load(
        url: String
    ): LoadResponse {

        val detailUrl = fixUrl(url)
        val document = fetchSiteDocument(detailUrl)

        val title = document
            .selectFirst("h1.entry-title")
            ?.text()
            ?.trim()
            .orEmpty()

        val detailImage = document
            .selectFirst("div.thumb img, div.ime img, img.wp-post-image")
            ?.selectImage()
        val ogPoster = document
            .selectFirst("meta[property=og:image]")
            ?.attr("content")
            ?.trim()
        val rawPoster = detailImage?.url ?: ogPoster
        val posterSource = when {
            detailImage?.url != null -> detailImage.source
            !ogPoster.isNullOrBlank() -> "og:image"
            else -> "none"
        }

        val fixedPoster = rawPoster?.let { fixUrlNull(it) }
        val poster = fixedPoster.orEmpty()

        Log.i(
            "Anichin",
            "ANICHIN_V67_DETAIL_POSTER source=$posterSource " +
                "host=${fixedPoster?.let(::hostOf).orEmpty()} url=$poster"
        )

        val description = extractSynopsis(document)

        val type = document
            .selectFirst(".spe")
            ?.text()
            .orEmpty()

        val tvType = if (type.contains("Movie", true)) {
            TvType.Movie
        } else {
            TvType.TvSeries
        }

        return if (tvType == TvType.TvSeries) {

            /*
             * Series pages expose their rows through .eplister. The cards in
             * Latest Release, however, point directly to an episode page.
             * Those pages already contain the full series list in the
             * #singlepisode sidebar, so reuse it instead of making another
             * network request to the series page.
             */
            val standardEpisodeRows = document.select(".eplister li")
            val sidebarEpisodeRows = if (standardEpisodeRows.isEmpty()) {
                document.select("#singlepisode .episodelist li")
            } else {
                emptyList()
            }
            val episodeRows = if (standardEpisodeRows.isNotEmpty()) {
                standardEpisodeRows
            } else {
                sidebarEpisodeRows
            }

            val episodeSource = when {
                standardEpisodeRows.isNotEmpty() -> "series-list"
                sidebarEpisodeRows.isNotEmpty() -> "episode-sidebar"
                else -> "single-fallback"
            }

            val episodes = episodeRows
                .mapNotNull { episodeElement ->

                    val rawLink = episodeElement
                        .selectFirst("a[href]")
                        ?.attr("href")
                        ?.trim()
                        .orEmpty()

                    if (rawLink.isBlank()) {
                        return@mapNotNull null
                    }

                    val link = fixUrl(rawLink)

                    val episodeTitle = episodeElement
                        .selectFirst(".epl-title, .playinfo h3")
                        ?.text()
                        ?.trim()
                        .orEmpty()

                    val episodeSub = episodeElement
                        .selectFirst(".epl-sub span")
                        ?.text()
                        ?.trim()
                        .orEmpty()

                    val episodeDate = episodeElement
                        .selectFirst(".epl-date")
                        ?.text()
                        ?.trim()
                        .orEmpty()
                        .ifBlank {
                            episodeElement
                                .selectFirst(".playinfo span")
                                ?.text()
                                ?.substringAfter(" - ", "")
                                ?.trim()
                                .orEmpty()
                        }

                    val episodePoster = poster
                        .takeIf { it.isNotBlank() }
                        ?: episodeElement
                            .selectFirst("a img")
                            ?.selectImage()
                            ?.url
                            ?.let { fixUrlNull(it) }

                    val episodeNumber = episodeNumberFrom(
                        episodeElement,
                        link,
                        episodeTitle
                    )

                    val cleanTitle = cleanEpisodeDisplayTitle(
                        episodeTitle,
                        episodeNumber
                    )

                    val episodeName = buildString {
                        if (cleanTitle.isNotBlank()) {
                            append(cleanTitle)
                        }

                        if (episodeSub.isNotBlank()) {
                            if (isNotEmpty()) append(" ")
                            append(episodeSub)
                            append(" Indonesia")
                        }
                    }.trim()

                    val episodeDescription =
                        episodeDate
                            .takeIf { it.isNotEmpty() }
                            ?.let { "Rilis: $it" }

                    newEpisode(link) {
                        this.name = episodeName
                        this.posterUrl = episodePoster
                        this.description = episodeDescription

                        if (
                            episodeNumber != null &&
                            episodeNumber % 1.0 == 0.0
                        ) {
                            this.episode = episodeNumber.toInt()
                        }
                    }
                }
                .reversed()

            val resolvedEpisodes = episodes.ifEmpty {
                val currentEpisodeNumber = episodeNumberFrom(
                    document,
                    detailUrl,
                    title
                )

                listOf(
                    newEpisode(detailUrl) {
                        this.name = cleanEpisodeDisplayTitle(
                            title,
                            currentEpisodeNumber
                        )
                        this.posterUrl = poster.takeIf { it.isNotBlank() }

                        if (
                            currentEpisodeNumber != null &&
                            currentEpisodeNumber % 1.0 == 0.0
                        ) {
                            this.episode = currentEpisodeNumber.toInt()
                        }
                    }
                )
            }

            val seriesAnchor = document
                .selectFirst("#singlepisode .headlist h2 a[href]")
            val responseTitle = seriesAnchor
                ?.text()
                ?.trim()
                ?.takeIf { it.isNotBlank() }
                ?: title
            val responseUrl = seriesAnchor
                ?.attr("href")
                ?.trim()
                ?.takeIf { it.isNotBlank() }
                ?.let { fixUrl(it) }
                ?: detailUrl

            Log.i(
                "Anichin",
                "ANICHIN_V67_EPISODES mode=$episodeSource " +
                    "count=${resolvedEpisodes.size} title=$responseTitle"
            )

            newTvSeriesLoadResponse(
                responseTitle,
                responseUrl,
                TvType.Anime,
                resolvedEpisodes
            ) {
                this.posterUrl = poster.takeIf { it.isNotBlank() }
                this.posterHeaders = imageHeadersFor(poster)
                this.plot = description
            }

        } else {

            val movieHref = document
                .selectFirst(".eplister li > a")
                ?.attr("href")
                ?.let { fixUrl(it) }
                ?: url

            newMovieLoadResponse(
                title,
                movieHref,
                TvType.Movie,
                movieHref
            ) {
                this.posterUrl = poster.takeIf { it.isNotBlank() }
                this.posterHeaders = imageHeadersFor(poster)
                this.plot = description
            }
        }
    }

    /* V13 load-link pipeline starts here. */

    private fun absoluteUrl(
        base: String,
        raw: String
    ): String? {
        val value = raw.trim()
            .replace("&amp;", "&")
            .replace("\\/", "/")

        if (value.isBlank()) return null
        if (value.startsWith("javascript:", ignoreCase = true)) return null

        return try {
            when {
                value.startsWith("//") -> {
                    val scheme = URI(base).scheme ?: "https"
                    "$scheme:$value"
                }
                value.startsWith("http://") || value.startsWith("https://") -> value
                else -> URI(base).resolve(value).toString()
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun decodePlayerValue(
        rawValue: String,
        baseUrl: String
    ): String? {
        val value = rawValue.trim()
        if (value.isBlank()) return null

        val looksLikeUrl = value.startsWith("http://", true) ||
            value.startsWith("https://", true) ||
            value.startsWith("//") ||
            value.startsWith("/") ||
            value.startsWith("./") ||
            value.startsWith("../")

        if (looksLikeUrl) {
            return absoluteUrl(baseUrl, value)
        }

        Regex(
            """<iframe[^>]+(?:src|data-src)\s*=\s*["']([^"']+)["']""",
            RegexOption.IGNORE_CASE
        ).find(value)
            ?.groupValues
            ?.getOrNull(1)
            ?.let { return absoluteUrl(baseUrl, it) }

        val decoded = runCatching {
            String(Base64.decode(value, Base64.DEFAULT))
        }.getOrNull() ?: return null

        Regex(
            """<iframe[^>]+(?:src|data-src)\s*=\s*["']([^"']+)["']""",
            RegexOption.IGNORE_CASE
        ).find(decoded)
            ?.groupValues
            ?.getOrNull(1)
            ?.let { return absoluteUrl(baseUrl, it) }

        return Regex(
            """https?://[^\s"'<>]+""",
            RegexOption.IGNORE_CASE
        ).find(decoded)
            ?.value
            ?.let { absoluteUrl(baseUrl, it) }
    }

    private fun isDirectMediaUrl(url: String): Boolean {
        val clean = url.substringBefore('#').lowercase()
        return clean.contains(".m3u8") ||
            clean.contains(".mpd") ||
            clean.contains(".mp4")
    }

    private fun isLikelyPlayerUrl(url: String): Boolean {
        val value = url.lowercase()
        if (isDirectMediaUrl(value)) return true

        return PLAYER_HOST_HINTS.any { value.contains(it) }
    }

    private fun playerLabelScore(label: String): Int {
        val value = label.trim().lowercase()
        return when {
            value.isBlank() || value == "server" -> 0
            value.startsWith("direct ") ||
                value.startsWith("embedded ") ||
                value.startsWith("fallback ") -> 1
            else -> 10
        }
    }

    private fun dedupePlayers(players: List<PlayerOption>): List<PlayerOption> {
        return players
            .filter { it.url.startsWith("http") }
            .groupBy { it.url }
            .values
            .mapNotNull { matches ->
                matches.maxWithOrNull(
                    compareBy<PlayerOption> { it.selectionRank }
                        .thenBy { playerLabelScore(it.label) }
                )
            }
            .sortedWith(
                compareBy<PlayerOption> { it.priority() }
                    .thenByDescending { it.selectionRank }
            )
    }

    private fun serverDisplayName(label: String, url: String): String {
        val cleanLabel = label
            .replace(
                Regex("""\s*\[(?:ads?|setting\s+dns)\]\s*""", RegexOption.IGNORE_CASE),
                " "
            )
            .replace(Regex("""\s+"""), " ")
            .trim()

        val host = runCatching { URI(url).host.orEmpty().lowercase() }
            .getOrDefault("")

        val hasWebsiteLabel = playerLabelScore(cleanLabel) >= 10

        // Keep explicit website labels bound to their wrapper. "New Player"
        // is the only ambiguous label because the site currently uses it for
        // more than one unrelated host.
        if (
            hasWebsiteLabel &&
            !cleanLabel.equals("New Player", ignoreCase = true)
        ) {
            return cleanLabel
        }

        return when {
            host.contains("dailymotion") || host.contains("dmcdn") -> "Dailymotion"
            host == "ok.ru" || host.endsWith(".ok.ru") ||
                host.contains("odnoklassniki") || host.contains("mycdn") -> "OK.ru"
            host.contains("rumble") -> "Rumble"
            host.contains("rpmvid") -> "RPM Share"
            host == "d.tube" || host.endsWith(".d.tube") -> "D-Tube"
            host.contains("turbovidhls") -> "TurboVid"
            host.contains("abyssplayer") -> "AbyssPlayer"
            host.contains("morencius") || host.contains("vidhide") -> "Vidhide"
            host.contains("anichin-player") -> "Dailymotion"
            host.contains("drive.google") || host.contains("googleusercontent") -> "Google Drive"
            host.contains("streamruby") || host.contains("rubyvid") -> "StreamRuby"
            host.contains("streamwish") || host.contains("wish") -> "StreamWish"
            host.contains("emturbovid") || host.contains("turboviplay") -> "Emturbovid"
            host.contains("filemoon") -> "Filemoon"
            host.contains("streamtape") -> "Streamtape"
            host.contains("mixdrop") -> "Mixdrop"
            hasWebsiteLabel -> cleanLabel
            host.isNotBlank() -> host.removePrefix("www.")
            else -> "Server"
        }
    }

    private fun extractorLinkScore(link: ExtractorLink): Int {
        val url = link.url.lowercase()
        val quality = link.quality.coerceAtLeast(0)

        return when {
            url.contains("master.m3u8") || url.contains("master_") -> 1_000_000 + quality
            link.type == ExtractorLinkType.M3U8 &&
                link.quality == Qualities.Unknown.value -> 900_000
            link.type == ExtractorLinkType.M3U8 -> 800_000 + quality
            link.type == ExtractorLinkType.DASH -> 700_000 + quality
            else -> 100_000 + quality
        }
    }

    private fun isAdaptiveMaster(link: ExtractorLink): Boolean {
        if (link.type != ExtractorLinkType.M3U8) return false

        val url = link.url.lowercase()
        return link.quality == Qualities.Unknown.value ||
            url.contains("master.m3u8") ||
            url.contains("master_")
    }

    private fun isAllowedQuality(link: ExtractorLink): Boolean {
        return link.url.isNotBlank() &&
            (link.quality >= MIN_VIDEO_QUALITY || isAdaptiveMaster(link))
    }

    private fun qualityLabel(link: ExtractorLink): String {
        return if (link.quality >= MIN_VIDEO_QUALITY) {
            "${link.quality}p"
        } else {
            "Auto"
        }
    }

    private fun qualityOrder(link: ExtractorLink): Int {
        return if (qualityLabel(link) == "Auto") Int.MAX_VALUE else link.quality
    }

    private suspend fun withWebsiteServerName(
        link: ExtractorLink,
        serverName: String
    ): ExtractorLink {
        val displayName = if (qualityLabel(link) == "Auto") {
          "$serverName • Auto"
        } else {
           serverName
        }

        return newExtractorLink(
            source = displayName,
            name = displayName,
            url = link.url,
            type = link.type
        ) {
            this.referer = link.referer
            this.headers = link.headers
            this.quality = link.quality
            this.extractorData = link.extractorData
            this.audioTracks = link.audioTracks
        }
    }

    private fun playerRequestHeaders(): Map<String, String> = mapOf(
        "User-Agent" to USER_AGENT,
        "Accept" to "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language" to "en-US,en;q=0.9,id;q=0.8",
        "Sec-Fetch-Dest" to "iframe",
        "Sec-Fetch-Mode" to "navigate"
    )

    private fun decodeBase64Text(value: String): String? {
        val token = value.trim()
        if (token.length < 20) return null

        return runCatching {
            String(Base64.decode(token, Base64.DEFAULT))
        }.getOrElse {
            runCatching {
                String(Base64.decode(token, Base64.URL_SAFE))
            }.getOrNull()
        }
    }

    private fun extractPlayerUrlsFromText(
        rawText: String,
        baseUrl: String
    ): List<String> {
        val text = rawText
            .replace("\\/", "/")
            .replace("\\u0026", "&")
            .replace("\\u003d", "=")
            .replace("&amp;", "&")
            .replace("&quot;", "\"")

        val urls = mutableListOf<String>()

        Regex(
            """<iframe[^>]+(?:src|data-src|data-video|data-embed)\s*=\s*[\"']([^\"']+)[\"']""",
            RegexOption.IGNORE_CASE
        ).findAll(text).forEach { match ->
            match.groupValues.getOrNull(1)
                ?.let { absoluteUrl(baseUrl, it) }
                ?.let(urls::add)
        }

        Regex(
            """(?:file|source|src|url|embed|player|video)\s*[:=]\s*[\"'](https?://[^\"']+)[\"']""",
            setOf(RegexOption.IGNORE_CASE, RegexOption.MULTILINE)
        ).findAll(text).forEach { match ->
            match.groupValues.getOrNull(1)
                ?.let { absoluteUrl(baseUrl, it) }
                ?.let(urls::add)
        }

        Regex(
            """https?://[^\s\"'<>\\]+""",
            RegexOption.IGNORE_CASE
        ).findAll(text).forEach { match ->
            val url = match.value
                .replace("\\/", "/")
                .trimEnd(')', ']', '}', ',', ';')

            if (isLikelyPlayerUrl(url)) {
                absoluteUrl(baseUrl, url)?.let(urls::add)
            }
        }

        Regex(
            """[\"']([A-Za-z0-9+/_=-]{24,})[\"']"""
        ).findAll(text).forEach { match ->
            val encoded = match.groupValues.getOrNull(1) ?: return@forEach
            val decoded = decodeBase64Text(encoded) ?: return@forEach

            Regex(
                """<iframe[^>]+(?:src|data-src)\s*=\s*[\"']([^\"']+)[\"']""",
                RegexOption.IGNORE_CASE
            ).findAll(decoded).forEach { iframe ->
                iframe.groupValues.getOrNull(1)
                    ?.let { absoluteUrl(baseUrl, it) }
                    ?.let(urls::add)
            }

            Regex(
                """https?://[^\s\"'<>]+""",
                RegexOption.IGNORE_CASE
            ).findAll(decoded).forEach { urlMatch ->
                val url = urlMatch.value.replace("\\/", "/")
                if (isLikelyPlayerUrl(url)) {
                    absoluteUrl(baseUrl, url)?.let(urls::add)
                }
            }
        }

        return urls
            .filter { it.startsWith("http") }
            .distinct()
    }

    private fun Document.collectTopLevelPlayers(
        pageUrl: String
    ): List<PlayerOption> {
        val players = mutableListOf<PlayerOption>()

        select(
            "#embed_holder iframe[src], " +
                "#embed_holder iframe[data-src], " +
                ".player-embed iframe[src], " +
                ".player-embed iframe[data-src], " +
                ".embed_holder iframe[src], " +
                ".embed_holder iframe[data-src], " +
                "iframe.metaframe[src], " +
                "iframe[src], iframe[data-src]"
        ).forEachIndexed { index, iframe ->
            val src = iframe.attr("src")
                .ifBlank { iframe.attr("data-src") }

            val url = absoluteUrl(pageUrl, src)
                ?: return@forEachIndexed

            if (!isLikelyPlayerUrl(url)) return@forEachIndexed

            players.add(
                PlayerOption(
                    label = "Direct ${index + 1}",
                    url = url,
                    selectionRank = DIRECT_IFRAME_RANK
                )
            )
        }

        select(
            ".mobius option, " +
                "select.mirror option, " +
                ".mirror option, " +
                ".server option, " +
                "option[data-index], " +
                "option[data-video], " +
                "option[data-src], " +
                "option[data-embed], " +
                "option[data-url], " +
                "option[data-link], " +
                "option[data-player], " +
                "option[value]"
        ).forEach { option ->
            val label = option.text()
                .trim()
                .ifBlank { option.attr("data-index").trim() }
                .ifBlank { "Server" }

            val candidates = listOf(
                option.attr("value"),
                option.attr("data-video"),
                option.attr("data-src"),
                option.attr("data-embed"),
                option.attr("data-url"),
                option.attr("data-link"),
                option.attr("data-player"),
                option.attr("data-iframe")
            )

            candidates.forEach { raw ->
                val url = decodePlayerValue(raw, pageUrl)
                    ?: return@forEach

                players.add(
                    PlayerOption(
                        label = label,
                        url = url,
                        selectionRank = LABELED_SERVER_RANK
                    )
                )
            }
        }

        select(
            "[data-video], [data-embed], [data-player], [data-url], [data-link], [data-iframe]"
        ).forEach { element ->
            listOf(
                element.attr("data-video"),
                element.attr("data-embed"),
                element.attr("data-player"),
                element.attr("data-url"),
                element.attr("data-link"),
                element.attr("data-iframe")
            ).forEach { raw ->
                decodePlayerValue(raw, pageUrl)?.let { url ->
                    if (isLikelyPlayerUrl(url)) {
                        players.add(
                            PlayerOption(
                                label = element.text().trim().ifBlank { "Server" },
                                url = url,
                                selectionRank = DATA_ATTRIBUTE_RANK
                            )
                        )
                    }
                }
            }
        }

        extractPlayerUrlsFromText(html(), pageUrl).forEachIndexed { index, url ->
            players.add(
                PlayerOption(
                    label = "Embedded ${index + 1}",
                    url = url,
                    selectionRank = EMBEDDED_TEXT_RANK
                )
            )
        }

        return dedupePlayers(players)
    }

    private fun Document.collectNestedPlayerUrls(
        pageUrl: String
    ): List<String> {
        val urls = mutableListOf<String>()

        select(
            "iframe[src], " +
                "iframe[data-src], " +
                "video source[src], " +
                "source[src], " +
                "video[src], " +
                "[data-video], [data-embed], [data-player], [data-url], [data-link], [data-iframe]"
        ).forEach { element ->
            listOf(
                element.attr("src"),
                element.attr("data-src"),
                element.attr("data-video"),
                element.attr("data-embed"),
                element.attr("data-player"),
                element.attr("data-url"),
                element.attr("data-link"),
                element.attr("data-iframe")
            ).forEach { raw ->
                if (raw.isBlank()) return@forEach

                val decoded = decodePlayerValue(raw, pageUrl)
                    ?: absoluteUrl(pageUrl, raw)

                if (decoded != null && isLikelyPlayerUrl(decoded)) {
                    urls.add(decoded)
                }
            }
        }

        select("script, textarea").forEach { element ->
            val scriptText = element.data()
                .ifBlank { element.html() }

            urls.addAll(
                extractPlayerUrlsFromText(
                    scriptText,
                    pageUrl
                )
            )
        }

        urls.addAll(extractPlayerUrlsFromText(html(), pageUrl))

        return urls
            .filter { it.startsWith("http") }
            .distinct()
    }

    private suspend fun fetchDocument(
        url: String,
        referer: String
    ): Document? {
        val referers = listOf(
            referer,
            "$mainUrl/",
            "https://anichin.care/"
        ).filter { it.isNotBlank() }.distinct()

        for (candidateReferer in referers) {
            val document = try {
                withTimeoutOrNull(PLAYER_REQUEST_TIMEOUT_MS) {
                    app.get(
                        url,
                        referer = candidateReferer,
                        headers = playerRequestHeaders()
                    ).document
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                null
            }

            if (document != null) {
                val hasPlayer = document.collectNestedPlayerUrls(url).isNotEmpty()
                if (hasPlayer || !url.contains("anichin-player.web.id", true)) {
                    return document
                }
            }
        }

        return null
    }

    private suspend fun tryLoadExtractor(
        url: String,
        referer: String,
        serverLabel: String,
        attemptedUrls: MutableSet<String>,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        val attemptKey = "$url\u0000$referer"

        if (!attemptedUrls.add(attemptKey)) {
            return false
        }

        if (isDirectMediaUrl(url)) {
            val displayName = serverDisplayName(serverLabel, url)

            val type = when {
                url.contains(".m3u8", true) -> ExtractorLinkType.M3U8
                url.contains(".mpd", true) -> ExtractorLinkType.DASH
                else -> ExtractorLinkType.VIDEO
            }

            callback(
                newExtractorLink(
                    source = displayName,
                    name = displayName,
                    url = url,
                    type = type
                ) {
                    this.referer = referer
                    this.headers = mapOf("User-Agent" to USER_AGENT)
                    this.quality = Qualities.Unknown.value
                }
            )
            return true
        }

        val emitted = AtomicBoolean(false)
        val discoveredUrls: MutableSet<String> =
            ConcurrentHashMap.newKeySet()

        val wrappedCallback: (ExtractorLink) -> Unit = { link ->
            if (discoveredUrls.add(link.url)) {
                emitted.set(true)
                callback(link)
            }
        }

        return try {
            withTimeoutOrNull(EXTRACTOR_TIMEOUT_MS) {
                loadExtractor(
                    url,
                    referer,
                    subtitleCallback,
                    wrappedCallback
                )
            }
            emitted.get()
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            false
        }
    }

    private suspend fun <T> collectSuccessful(
        items: List<T>,
        concurrency: Int,
        block: suspend (T) -> Boolean
    ): Boolean = coroutineScope {
        if (items.isEmpty()) {
            return@coroutineScope false
        }

        val semaphore = Semaphore(concurrency.coerceAtLeast(1))

        items.map { item ->
            async {
                semaphore.withPermit {
                    try {
                        block(item)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (_: Exception) {
                        false
                    }
                }
            }
        }
            .awaitAll()
            .any { it }
    }

    private suspend fun <T> collectFirstSuccessfulSequentially(
        items: List<T>,
        block: suspend (T) -> Boolean
    ): Boolean {
        for (item in items) {
            val succeeded = try {
                block(item)
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                false
            }

            if (succeeded) return true
        }

        return false
    }

    private suspend fun resolvePlayerPipeline(
        wrapperUrl: String,
        episodeUrl: String,
        serverLabel: String,
        attemptedUrls: MutableSet<String>,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        val directSuccess = tryLoadExtractor(
            wrapperUrl,
            episodeUrl,
            serverLabel,
            attemptedUrls,
            subtitleCallback,
            callback
        )

        if (directSuccess) return true

        val wrapperDocument = fetchDocument(
            wrapperUrl,
            episodeUrl
        ) ?: return false

        val playerUrls = wrapperDocument.collectNestedPlayerUrls(wrapperUrl)

        return collectSuccessful(
            playerUrls,
            MAX_NESTED_CONCURRENCY
        ) { playerUrl ->
            val playerSuccess = tryLoadExtractor(
                playerUrl,
                wrapperUrl,
                serverLabel,
                attemptedUrls,
                subtitleCallback,
                callback
            )

            if (playerSuccess) {
                true
            } else {
                val nestedDocument = fetchDocument(
                    playerUrl,
                    wrapperUrl
                )

                if (nestedDocument == null) {
                    false
                } else {
                    val nestedUrls = nestedDocument.collectNestedPlayerUrls(playerUrl)

                    collectSuccessful(
                        nestedUrls,
                        MAX_NESTED_CONCURRENCY
                    ) { nestedUrl ->
                        tryLoadExtractor(
                            nestedUrl,
                            playerUrl,
                            serverLabel,
                            attemptedUrls,
                            subtitleCallback,
                            callback
                        )
                    }
                }
            }
        }
    }

    override suspend fun loadLinks(
        data: String,
        isCasting: Boolean,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        val document = withTimeoutOrNull(EPISODE_REQUEST_TIMEOUT_MS) {
            fetchSiteDocument(data)
        } ?: return false

        val needsClosedCaptions = document.text().contains(
            "AKTIFKAN SUB CC",
            ignoreCase = true
        )

        val emittedSubtitleUrls: MutableSet<String> =
            ConcurrentHashMap.newKeySet()

        val effectiveSubtitleCallback: (SubtitleFile) -> Unit = { subtitle ->
            if (
                needsClosedCaptions &&
                emittedSubtitleUrls.add(subtitle.url)
            ) {
                subtitleCallback(subtitle)
            }
        }

        val topLevelPlayers = document.collectTopLevelPlayers(data)
        val nestedPlayers = document.collectNestedPlayerUrls(data)

        val players = buildList {
            addAll(topLevelPlayers)
            nestedPlayers.forEachIndexed { index, url ->
                add(
                    PlayerOption(
                        label = "Fallback ${index + 1}",
                        url = url,
                        selectionRank = NESTED_FALLBACK_RANK
                    )
                )
            }
        }
            .let(::dedupePlayers)

        Log.w(
            "Anichin",
            "ANICHIN_V67_DISCOVERY page=${data.substringAfter(mainUrl).take(90)} " +
                "top=${topLevelPlayers.size} nested=${nestedPlayers.size} merged=${players.size} " +
                "hosts=${players.take(8).joinToString(" | ") { runCatching { URI(it.url).host }.getOrNull().orEmpty() }}"
        )

        if (players.isEmpty()) {
            Log.w("Anichin", "ANICHIN_V67_DONE candidates=0 success=false")
            return false
        }

        val emittedUrls: MutableSet<String> =
            ConcurrentHashMap.newKeySet()
        val emittedServerQualities: MutableSet<String> =
            ConcurrentHashMap.newKeySet()
        val emittedCount = java.util.concurrent.atomic.AtomicInteger(0)
        val emissionLock = Any()

        suspend fun resolveAndEmit(player: PlayerOption): Boolean {
            val serverAttempts: MutableSet<String> =
                ConcurrentHashMap.newKeySet()
            val serverLinks: MutableList<ExtractorLink> =
                Collections.synchronizedList(mutableListOf())

            val pipelineTimeout = when (player.priority()) {
                0 -> OKRU_PIPELINE_TIMEOUT_MS
                2 -> DAILYMOTION_PIPELINE_TIMEOUT_MS
                1 -> PREFERRED_PIPELINE_TIMEOUT_MS
                else -> FALLBACK_PIPELINE_TIMEOUT_MS
            }

            withTimeoutOrNull(pipelineTimeout) {
                coroutineScope {
                    val masterFound = CompletableDeferred<Unit>()
                    val pipeline = async {
                        resolvePlayerPipeline(
                            player.url, data, player.label, serverAttempts,
                            effectiveSubtitleCallback,
                            { link ->
                                serverLinks.add(link)
                                if (isAdaptiveMaster(link)) masterFound.complete(Unit)
                            }
                        )
                    }
                    // Cancel remaining work for this server as soon as its
                    // master arrives. Other server families continue normally.
                    select<Unit> {
                        masterFound.onAwait { pipeline.cancel() }
                        pipeline.onAwait { }
                    }
                    pipeline.join()
                }
            }

            val eligibleLinks = serverLinks
                .filter(::isAllowedQuality)
                .distinctBy { link -> link.url }

            /*
             * One clean source per website. A native master already contains
             * every adaptive track, so do not repeat its 1080p/720p children.
             * Use a fixed fallback only when no master was found.
             */
            val rawMasterLink = eligibleLinks
                .filter(::isAdaptiveMaster)
                .maxByOrNull(::extractorLinkScore)

            val fixedFallbacks = eligibleLinks
                .filterNot(::isAdaptiveMaster)
                .sortedByDescending(::qualityOrder)

            // Resolve the display name from the original website option and
            // wrapper URL once. Nested extractors must not rename the result
            // after following a CDN or another internal player.
            val resolvedServerName = serverDisplayName(
                player.label,
                player.url
            )

            // Pass the website's native master URL straight to Cloudstream.
            // Rebuilding it as a data URI delays startup and is unsupported by
            // some ExoPlayer/Cloudstream versions.
            val orderedLinks = when {
                rawMasterLink != null -> listOf(rawMasterLink)
                player.priority() == 1 -> fixedFallbacks.distinctBy { it.quality }
                else -> listOfNotNull(fixedFallbacks.firstOrNull())
            }

            var emittedForServer = false

            for (link in orderedLinks) {
                val displayKey = "$resolvedServerName\u0000${qualityLabel(link)}"

                val shouldEmit = synchronized(emissionLock) {
                    val normalizedKey = displayKey.lowercase()
                    if (
                        emittedUrls.contains(link.url) ||
                        emittedServerQualities.contains(normalizedKey)
                    ) {
                        false
                    } else {
                        emittedUrls.add(link.url)
                        emittedServerQualities.add(normalizedKey)
                        true
                    }
                }

                if (shouldEmit) {
                    callback(withWebsiteServerName(link, resolvedServerName))
                    emittedCount.incrementAndGet()
                    emittedForServer = true
                }
            }

            return emittedForServer
        }

        val preferredPlayers = players.filter { it.priority() <= 2 }
        val fallbackPlayers = players.filter { it.priority() > 2 }
        val preferredServerGroups = preferredPlayers
            .groupBy { it.priority() }
            .values
            .toList()

        val preferredSuccess = withTimeoutOrNull(
            PREFERRED_GROUP_TIMEOUT_MS
        ) {
            /*
             * Start one lane for each preferred server family so duplicate
             * wrapper URLs cannot prevent OK.ru, Rumble or Dailymotion from
             * running. Each successful pipeline emits immediately, while the
             * other two lanes continue inside this active loadLinks call.
             */
            collectSuccessful(
                preferredServerGroups,
                PREFERRED_SERVER_CONCURRENCY,
            ) { serverPlayers ->
                val exactServerPlayers = if (
                    serverPlayers.firstOrNull()?.priority() == 1
                ) {
                    serverPlayers
                        .filter { it.selectionRank == LABELED_SERVER_RANK }
                        .ifEmpty { serverPlayers }
                } else {
                    serverPlayers
                }

                collectFirstSuccessfulSequentially(
                    exactServerPlayers,
                    ::resolveAndEmit
                )
            }
        } ?: (emittedCount.get() > 0)

        val fallbackAttempted = !preferredSuccess && emittedCount.get() == 0

        val fallbackSuccess = if (fallbackAttempted) {
            withTimeoutOrNull(FALLBACK_GROUP_TIMEOUT_MS) {
                collectSuccessful(
                    fallbackPlayers,
                    FALLBACK_SERVER_CONCURRENCY,
                    ::resolveAndEmit
                )
            } ?: (emittedCount.get() > 0)
        } else {
            false
        }

        val success = preferredSuccess || fallbackSuccess || emittedCount.get() > 0

        Log.w(
            "Anichin",
            "ANICHIN_V67_DONE candidates=${players.size} preferred=${preferredPlayers.size} " +
                "fallbackAttempted=$fallbackAttempted emitted=${emittedCount.get()} success=$success"
        )

        return success
    }

    private fun PlayerOption.priority(): Int {
        val value = "$label $url".lowercase()

        return when {
            value.contains("ok.ru") || value.contains("okru") || value.contains("odnoklassniki") -> 0
            value.contains("rumble") -> 1
            value.contains("dailymotion") -> 2
            value.contains("anichin-player.web.id") -> 3
            value.contains("streamruby") || value.contains("ruby") -> 4
            value.contains("rpmvid") -> 5
            value.contains("d.tube") -> 6
            value.contains("turbovidhls") || value.contains("turboviplay") ||
                value.contains("emturbovid") -> 7
            value.contains("abyssplayer") -> 8
            value.contains("morencius") || value.contains("vidhide") -> 9
            else -> 20
        }
    }

    companion object {
        private const val HOMEPAGE_LATEST_ROUTE = "__homepage_latest_v58_rilisan_terbaru__"
        private const val LATEST_ARCHIVE_ROUTE = "anime/?order=update"
        private val LATEST_HEADING_LABELS = listOf(
            "Latest Release",
            "Latest Update",
            "Rilisan Terbaru",
            "Rilis Terbaru",
            "Episode Terbaru",
            "Update Terbaru"
        )
        private val sharedCloudflareKiller by lazy { CloudflareCompat() }

        private val PLAYER_HOST_HINTS = listOf(
            "ok.ru",
            "odnoklassniki",
            "dailymotion",
            "rumble",
            "anichin-player.web.id",
            "rpmvid",
            "d.tube",
            "turbovidhls",
            "abyssplayer",
            "streamruby",
            "rubyvid",
            "emturbovid",
            "turboviplay",
            "morencius",
            "vidhide",
            "dood",
            "streamwish",
            "wish",
            "odysee.com",
            "odycdn.com",
            "mega.nz",
            "megacloud",
            "filemoon",
            "streamtape",
            "mixdrop"
        )

        private const val MAX_NESTED_CONCURRENCY = 3
        private const val PREFERRED_SERVER_CONCURRENCY = 3
        private const val FALLBACK_SERVER_CONCURRENCY = 3
        private const val EPISODE_REQUEST_TIMEOUT_MS = 8_000L
        private const val PLAYER_REQUEST_TIMEOUT_MS = 6_000L
        private const val EXTRACTOR_TIMEOUT_MS = 9_000L
        private const val PREFERRED_PIPELINE_TIMEOUT_MS = 6_000L
        private const val FALLBACK_PIPELINE_TIMEOUT_MS = 4_500L
        private const val OKRU_PIPELINE_TIMEOUT_MS = 9_000L
        private const val DAILYMOTION_PIPELINE_TIMEOUT_MS = 13_000L
        private const val PREFERRED_GROUP_TIMEOUT_MS = 14_000L
        private const val FALLBACK_GROUP_TIMEOUT_MS = 5_000L
        private const val SITE_REQUEST_TIMEOUT_SECONDS = 20L
        private const val HOME_CACHE_TTL_NS = 60 * 1_000_000_000L
        private const val LATEST_BLOCK_SEARCH_DEPTH = 4
        private const val LATEST_SIBLING_SEARCH_LIMIT = 3
        private const val LATEST_DIAGNOSTIC_LIMIT = 5
        private const val LABELED_SERVER_RANK = 100
        private const val DATA_ATTRIBUTE_RANK = 60
        private const val DIRECT_IFRAME_RANK = 30
        private const val EMBEDDED_TEXT_RANK = 10
        private const val NESTED_FALLBACK_RANK = 0
        private const val POSTER_DIAGNOSTIC_LIMIT = 3
        private const val MIN_POSTER_WIDTH = 300
        private const val MIN_VIDEO_QUALITY = 720
    }
}
