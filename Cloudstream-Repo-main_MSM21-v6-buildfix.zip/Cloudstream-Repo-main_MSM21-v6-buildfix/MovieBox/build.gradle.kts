version = 4
cloudstream {
    language = "en"
    description = "MovieBox — Streaming Movie Subtitle Indonesia"
    authors = listOf("Luckez")
    status = 1
    tvTypes = listOf(
        "TvSeries",
        "Movie",
        "Anime",
        "AsianDrama",
    )
    
    iconUrl = "https://movieboxph.app/wp-content/uploads/2025/11/Movie-Box-icon.webp"
}
