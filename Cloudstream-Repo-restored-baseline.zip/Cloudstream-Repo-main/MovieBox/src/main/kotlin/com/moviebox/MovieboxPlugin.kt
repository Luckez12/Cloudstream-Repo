package com.moviebox

import android.util.Log
import com.lagradost.cloudstream3.plugins.BasePlugin
import com.lagradost.cloudstream3.plugins.CloudstreamPlugin

@CloudstreamPlugin
class MovieboxPlugin : BasePlugin() {
    override fun load() {
        Log.i("MovieBox", "MOVIEBOX_PLUGIN_LOADED version=14 searchFlow=android-jsonnode playback=h5-direct-cdn-no-referrer")
        registerMainAPI(MovieboxProvider())
    }
}
